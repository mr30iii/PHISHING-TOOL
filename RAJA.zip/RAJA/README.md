<a href="https://github.com/mr30iii/PHISHING-TOOL.git"><img title="" src="./tool.png"></a>

# 💻PHISHING-TOOL🔗

## Installation :

---

- `apt update`
- `apt install git curl php openssh -y`
- `git clone https://github.com/mr30iii/PHISHING-TOOL.git`
- `cd PHISHING-TOOL`
- `bash raja-phisher.sh`

#### > Run : `bash zphisher.sh`

---

## Single Command :

```
apt update ; apt install git curl php openssh -y ; git clone https://github.com/mr30iii/PHISHING-TOOL.git ; cd PHISHING-TOOL ; bash raja-phisher.sh
```

<br>
<p align="center">
<img width="40%" src="https://raw.githubusercontent.com/htr-tech/release-download/master/images/zphisher1.png"/>
<img width="51%" src="https://raw.githubusercontent.com/htr-tech/release-download/master/images/zphisher2.png"/>
</p>

### <<< If you copy , Then Give me The Credits >>>

## Features :

#### [+] Latest Login Pages !

#### [+] New Instagram Auto Follower Page !

#### [+] 4 Port Forwarding Options !

#### [+] Easy for Beginners !

## Credits :

#### > TOOL-OWNER (https://github.com/mr30iii)

#### > TOOL-Developers (https://github.com/mr30iii)

#### > RAJA (https://github.com/mr30iii)

## Tunelling Options :

#### > Localhost (127.0.0.1)

#### > NGROK (https://ngrok.com)

#### > SERVEO (https://serveo.net)

#### > LOCALHOSTRUN (https://localhost.run)
#   P H I S H I N G - T O O L  
 